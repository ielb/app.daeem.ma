<?php
return [
    'datetime_display_format' => env('DATETIME_DISPLAY_FORMAT', 'd M Y H:i'),
];
