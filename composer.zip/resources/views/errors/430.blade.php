@extends('errors::minimal')

@section('title', __('Your account is not activate'))
@section('code', '430')
@section('message', __('Your account is not activate'))
