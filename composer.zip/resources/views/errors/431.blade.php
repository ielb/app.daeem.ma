@extends('errors::minimal')

@section('title', __('Permission Probleme'))
@section('code', '431')
@section('message', __('Sorry you dont have permission to this page !'))
