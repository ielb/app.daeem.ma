@extends('errors::minimal')

@section('title', __('Lien Expired'))
@section('code', '432')
@section('message', __('Lien Expired'))
